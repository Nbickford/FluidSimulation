# FluidSimulation
Hi! I'm currently writing what should hopefully eventually be a FLIP-based fluid simulator that runs and renders mostly on the GPU using Direct3D 11 (and some Shadertoy-like techniques) for simulation and visualization.
There's not much here at the moment, but give it a few days - I'm putting the work up here early to have a visible log of the programming as it progresses.